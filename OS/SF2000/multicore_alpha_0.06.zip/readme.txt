███████╗███████╗██████╗  ██████╗  ██████╗  ██████╗                    
██╔════╝██╔════╝╚════██╗██╔═████╗██╔═████╗██╔═████╗                   
███████╗█████╗   █████╔╝██║██╔██║██║██╔██║██║██╔██║                   
╚════██║██╔══╝  ██╔═══╝ ████╔╝██║████╔╝██║████╔╝██║                   
███████║██║     ███████╗╚██████╔╝╚██████╔╝╚██████╔╝                   
╚══════╝╚═╝     ╚══════╝ ╚═════╝  ╚═════╝  ╚═════╝                    
███╗   ███╗██╗   ██╗██╗  ████████╗██╗ ██████╗ ██████╗ ██████╗ ███████╗
████╗ ████║██║   ██║██║  ╚══██╔══╝██║██╔════╝██╔═══██╗██╔══██╗██╔════╝
██╔████╔██║██║   ██║██║     ██║   ██║██║     ██║   ██║██████╔╝█████╗  
██║╚██╔╝██║██║   ██║██║     ██║   ██║██║     ██║   ██║██╔══██╗██╔══╝  
██║ ╚═╝ ██║╚██████╔╝███████╗██║   ██║╚██████╗╚██████╔╝██║  ██║███████╗
╚═╝     ╚═╝ ╚═════╝ ╚══════╝╚═╝   ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝
┏┓┓  ┓     ┏┓ ┏┓┏┓
┣┫┃┏┓┣┓┏┓  ┃┫ ┃┫┣┓
┛┗┗┣┛┛┗┗┻  ┗┛•┗┛┗┛
   ┛              

The sf2000 multicore project is not ready for release, but since people
keep asking, these "alpha" releases might help. Use at your own risk!

The only place to get this official version is the Retro Handhelds discord 
in the "data_frog_sf2000" section at the "SF2000 Dev" thread. If shared 
elsewhere, please don't add or remove files. Feel free to include 
the readme.txt translated into additional languages, as long as the 
content stays the same. :)

┓ ┏┓┏┏┓┏┳┓╹┏┓  ┳┓┏┓┓ ┏┏┓
┃┃┃┣┫┣┫ ┃  ┗┓  ┃┃┣ ┃┃┃┏┛
┗┻┛┛┗┛┗ ┻  ┗┛  ┛┗┗┛┗┻┛• 

changes in 0.06:
- added several new known issues in the "beware" section
- created an empty /ROMS/save directory since it may not do so automatically
- renamed "pico" to "sega" for PicoDrive (for clarity)
- updated source code links
- rebuilt all cores again based on latest libretro sources
- added Genesis Plus GX	for accurate Sega MS/GG/MD/CD (thanks to @osaka!)

changes in 0.05:
- rebuilt all cores to include support for autoframeskip in opt
(some cores may not support this feature though)
- added PicoDrive with support for SegaCD and 32X (thanks to @osaka!)
- added MAME2000 (custom build from @kobil using different compiler tools)
- added section about log.txt
- updated fuse.opt file with comments on allowed key bindings

changes in 0.04:
- "snes" Snes9x 2005 audio samplerate reduced to 11025 for performance
- rebuild of cores released in v0.02, due to a bug that may have affected
performance; (CrocoDS , X Millennium, and Beetle SuperGrafx may be faster.)

changes in 0.03:
- added @kobil's "snesk" Snes9x 2005 (Nintendo SNES/SFC) which apparently
has better performance on certain games.
- new bootlogo with version number, thanks to @vonmillhausen

changes in 0.02:
- added Beetle SuperGrafx (NEC PC Engine/SuperGrafx)
- added X Millennium (Sharp X1)
- added bios location note for X Millennium (Sharp X1)
- added 2048 (Game)
- added LowRes NX (Fantasy Console)
- added CrocoDS (Amstrad CPC)

┳┓┏┓┓ ┏┏┓┳┓┏┓
┣┫┣ ┃┃┃┣┫┣┫┣ 
┻┛┗┛┗┻┛┛┗┛┗┗┛
             
The multiloader replaces the built-in GBA emulator in the original firmware 
with a new emulator when loading games. The built in GBA menu will NO LONGER
WORK. Consider modifying it with theme/menu hacks if you like, as it will no 
longer load GBA games. Instead, GBA games must be loaded through user rom stubs.

This release is for testing use only and future releases might break 
compatibility. For example the save state file format is currently not fully 
compatible with Retroarch. Directory names for emulators may change as well.

KNOWN ISSUES:
- this uses the official 1.6 Firmware with the SNES fix applied
- it does not have the battery fix applied
- it does not use 1.71 Firmware since there is no benefit
- original GBA menu DOES NOT WORK for loading .gba games
- button config tool in official firmware will break GBA button mapping in multicore!
- save state format is not compatible with Retroarch
- Using VERY LONG rom filenames causes problems, according to Von Millhausen:
https://discord.com/channels/741895796315914271/1099465777825972347/1164918661316890757

┓┏┏┓┓ ┏  ┏┳┓┏┓  ┳┳┏┓┏┓
┣┫┃┃┃┃┃   ┃ ┃┃  ┃┃┗┓┣ 
┛┗┗┛┗┻┛   ┻ ┗┛  ┗┛┗┛┗┛
                      
- install the bootloader fix:
	https://vonmillhausen.github.io/sf2000/#bootloader-bug
- install a full, clean 1.6 sf2000 firmware on the microsd card
- note: do not use 1.71
- optional: rename your /bios/bisrv.asd file to bisrv.old (make a backup)
            (To go back to using the official firmware, simply use you
            original bisrv.asd.)
- unzip the contents of this archive onto the microsd card
- read the sections below and copy supported rom and bios files

┏┳┓┓┏┏┓  ┓ ┏┓┏┓
 ┃ ┣┫┣   ┃ ┃┃┃┓
 ┻ ┛┗┗┛  ┗┛┗┛┗┛
               
A file called log.txt is created on the sdcard and every time a core is 
used it logs information to this file. If you're having problems, it's a 
good idea to check this file. It should tell you if it found bios files, 
if it's found and using an opt file, what settings it's using (and what 
the defaults are), and other useful information. If reporting a problem 
or asking for help on discord, it can be useful to attach this log file. 

The log file may grow quite large over time. You can safely delete it 
from the sdcard. 

┳┓┏┓┳┳┓  ┏┓┳┓ ┏┓┏┓
┣┫┃┃┃┃┃  ┣ ┃┃ ┣ ┗┓
┛┗┗┛┛ ┗  ┻ ┻┗┛┗┛┗┛
                  
The tables below list the rom directory system, and associated file 
extensions. Some file types may not yet be supported. Zip files 
generally do not work (except for MAME), so don't use compressed roms 
(zip, 7z, etc.) Once your roms are in place, run the make-romlist.bat 
(if using Windows) or make-romlist.sh (is using a Mac) to create all 
the stub files needed to run the games. This way, games will show up in 
the User section of the menu.

NOTE: Some extra entries will be created since it adds an entry for 
every file in the system rom folder. For instance, cavestory will 
have entries for the manual.html and other stuff. The only file you 
can run for cavestory is "Doukutsu.exe". You can either ignore or 
delete these extra junk stub files. In Windows, if you hide the files 
you want ignored, the batch file won't make stubs for them.

Do not ask for rom files on Discord!

┳┓┳┏┓┏┓  ┏┓┳┓ ┏┓┏┓
┣┫┃┃┃┗┓  ┣ ┃┃ ┣ ┗┓
┻┛┻┗┛┗┛  ┻ ┻┗┛┗┛┗┛
                  
Bios files go in /bios just like in the official sf2000 firmware.
Fuse (Sinclair ZX Spectrum) requires its bios files in /bios/fuse.
X Millennium (Sharp X1) requires its bios files in /bios/xmil.

To figure out which bios files you need and what to call them, read the
libretro docs and the links below.

Do not ask for bios files on Discord!

Emulator		System				BIOS
-------------------------------------------------------------------------------------------------------------------
a5200			Atari 5200			https://docs.libretro.com/library/atari800/#bios
Beetle PC-FX		NEC PC-FX			https://docs.libretro.com/library/beetle_pc_fx/#bios
Beetle PCE FAST		NEC PC Engine/CD		https://docs.libretro.com/library/beetle_pce_fast/#bios
Beetle SuperGrafx	NEC PC Engine/SuperGrafx	https://docs.libretro.com/library/beetle_sgx/#bios
FCEUmm			Nintendo NES/Famicom		https://docs.libretro.com/library/fceumm/#bios
FreeChaF		Fairchild ChannelF		https://github.com/libretro/FreeChaF
Fuse			Sinclair ZX Spectrum		https://docs.libretro.com/library/fuse/#bios
Gearcoleco		Coleco ColecoVision		https://docs.libretro.com/library/gearcoleco/#bios
Gearsystem		Sega MS/GG/SG-1000		https://docs.libretro.com/library/gearsystem/#bios
Genesis Plus GX		Sega MS/GG/MD/CD		https://docs.libretro.com/library/genesis_plus_gx/#bios
gpSP			Nintendo Game Boy Advance	https://docs.libretro.com/library/gpsp/#bios
Handy			Atari Lynx			https://docs.libretro.com/library/handy/#bios
MAME2000		Arcade/Console/various		https://docs.libretro.com/library/mame_2003/ (bios same)
O2EM			Magnavox Odyssey2		https://docs.libretro.com/library/o2em/#bios
PicoDrive		Sega MS/GG/MD/CD/32X		https://docs.libretro.com/library/picodrive/#bios
ProSystem		Atari 7800			https://docs.libretro.com/library/prosystem/#bios
X Millennium		Sharp X1			https://github.com/libretro/xmil-libretro
-------------------------------------------------------------------------------------------------------------------

┏┓┏┓┏┳┓  ┏┓┳┓ ┏┓┏┓
┃┃┃┃ ┃   ┣ ┃┃ ┣ ┗┓
┗┛┣┛ ┻   ┻ ┻┗┛┗┛┗┛
                  
The .opt files in /cores/config define specific settings for each emulator core. 
These are the options you'd normally see in Retroarch for each core. We've 
tried to include working default settings, but you may want to look at the 
files and customize them. There is no menu to change options on the sf2000.

┏┓┳┳┓┳┳┓ ┏┓┏┳┓┏┓┳┓  ┳┓┏┓┏┳┓┏┓┳┓ ┏┓
┣ ┃┃┃┃┃┃ ┣┫ ┃ ┃┃┣┫  ┃┃┣  ┃ ┣┫┃┃ ┗┓
┗┛┛ ┗┗┛┗┛┛┗ ┻ ┗┛┛┗  ┻┛┗┛ ┻ ┛┗┻┗┛┗┛
                                  
Emulators that work well, or perfectly

ROMS		Emulator		System				Extension
-------------------------------------------------------------------------------------------------------------------
2048		2048			Game				dummy
a26		Stella 2014		Atari 2600			a26|bin
cavestory	NXEngine		Game engine			exe
cdg		Pocket CDG		Karaoke player			cdg
chip8		JAXE			CHIP-8/S-CHIP/XO-CHIP		ch8|sc8|xo8|hc8
col		Gearcoleco		Coleco ColecoVision		col|cv|bin|rom
fcf		FreeChaF		Fairchild ChannelF		bin|rom|chf
gb		TGB Dual		Nintendo Game Boy/Color		gb|dmg|gbc|cgb|sgb
gba		gpSP			Nintendo Game Boy Advance	gba|bin|agb|gbz|u1
gg		Gearsystem		Sega MS/GG/SG-1000		sms|gg|sg|mv|bin|rom
gme		Game Music Emu		Music player			ay|gbs|gym|hes|kss|nsf|nsfe|sap|spc|vgm|vgz
gong		Gong			Game				gong
lnx		Handy			Atari Lynx			lnx|o
m2k		MAME2000		Arcade/Console/various		zip
nes		FCEUmm			Nintendo NES/Famicom		fds|nes|unf|unif
ngpc		RACE			Neo Geo Pocket/Color		ngp|ngc|ngpc|npc
pce		Beetle PCE FAST		NEC PC Engine/CD		pce|cue|ccd|chd|toc|m3u
retro8		Retro8			Fantasy Console			p8|png
sega		PicoDrive		Sega MS/GG/MD/CD/32X		bin|gen|smd|md|32x|cue|iso|sms|68k|chd
snes		Snes9x 2005		Nintendo SNES/SFC		smc|fig|sfc|gd3|gd7|dx2|bsx|swc
snesk		Snes9x 2005 (@kobil)	Nintendo SNES/SFC		smc|fig|sfc|gd3|gd7|dx2|bsx|swc
snes02		Snes9x 2002		Nintendo SNES/SFC		smc|fig|sfc|gd3|gd7|dx2|bsx|swc
spec		Fuse			Sinclair ZX Spectrum		tzx|tap|z80|rzx|scl|trd|dsk
thom		Theodore		Thomson MO/TO			fd|sap|k7|m7|m5|rom
vapor		VaporSpec		Fantasy Console			vaporbin
wsv		Potator			Watara Supervision		bin|sv
-------------------------------------------------------------------------------------------------------------------


Additional emulators that have issues

ROMS		Emulator		System				Issue			Extension
------------------------------------------------------------------------------------------------------------------------------------------
a5200		a5200			Atari 5200			some games crash	a52|bin
a78		ProSystem		Atari 7800			no sound; slow		a78|bin|cdf
amstrad		CrocoDS			Amstrad CPC			slow			dsk|sna|kcr
arduboy		Arduous			Arduboy				slow			hex
gpgx		Genesis Plus GX		Sega MS/GG/MD/CD		slow, but accurate	m3u|mdx|md|smd|gen|bin|cue|iso|chd|bms|sms|gg|sg|68k|sgd
jnb		Jump 'n Bump		Game engine			slow			dat
lowres-nx	LowRes NX		Fantasy Console			slow			nx
o2em		O2EM			Magnavox Odyssey2		slow			bin
pcesgx		Beetle SuperGrafx	NEC PC Engine/SuperGrafx	slow			pce|sgx|cue|ccd|chd
pcfx		Beetle PC-FX		NEC PC-FX			very slow		cue|ccd|toc|chd
prboom		PrBoom			Game engine			no sound		wad|iwad|pwad|lmp
vb		Beetle VB		Nintendo Virtual Boy		very slow		vb|vboy|bin
xmil		X Millennium		Sharp X1			slow			dx1|zip|2d|2hd|tfd|d88|88d|hdm|xdf|dup|cmd
------------------------------------------------------------------------------------------------------------------------------------------

The complete list of emulator cores and development status can be found in a spreadsheet at:
https://docs.google.com/spreadsheets/d/1BDPqLwRcY2cN7tObuyW7RzLw8oGyY9XGLS1D4jLgz2Q/edit?usp=sharing

┏┓┳┳┏┓┏┓┏┳┓┳┏┓┳┓┏┓┏┓
┃┃┃┃┣ ┗┓ ┃ ┃┃┃┃┃┗┓┏┛
┗┻┗┛┗┛┗┛ ┻ ┻┗┛┛┗┗┛• 
                    
Von Millhausen's SF2000 page is the single best source of information:
https://vonmillhausen.github.io/sf2000

General sf2000 questions can be asked on the discord here:
https://discord.com/channels/741895796315914271/1092831839955193987

Questions about test builds (like this one) can be asked here:
https://discord.com/channels/741895796315914271/1147949255911297155

Please use the SF2000 Dev channel for development related discussion only!
https://discord.com/channels/741895796315914271/1099465777825972347

┏┓┏┓┳┳┳┓┏┓┏┓  ┏┓┏┓┳┓┏┓
┗┓┃┃┃┃┣┫┃ ┣   ┃ ┃┃┃┃┣ 
┗┛┗┛┗┛┛┗┗┛┗┛  ┗┛┗┛┻┛┗┛

SF2000:                      
https://gitlab.com/kobily/sf2000_multicore
TODO: github repo for sf2000_multicore
https://github.com/madcock/sf2000_multicore_cores

Libretro:
https://github.com/libretro/libretro-2048
https://github.com/libretro/a5200
https://github.com/libretro/arduous
https://github.com/libretro/beetle-pce-fast-libretro
https://github.com/libretro/beetle-pcfx-libretro
https://github.com/libretro/beetle-supergrafx-libretro
https://github.com/libretro/beetle-vb-libretro
https://github.com/libretro/libretro-crocods
https://github.com/libretro/libretro-fceumm
https://github.com/libretro/FreeChaF
https://github.com/libretro/fuse-libretro
https://github.com/libretro/libretro-gme
https://github.com/drhelius/Gearcoleco
https://github.com/drhelius/Gearsystem
https://github.com/libretro/Genesis-Plus-GX
https://github.com/libretro/gong
https://github.com/libretro/gpsp
https://github.com/libretro/libretro-handy
https://github.com/libretro/jumpnbump-libretro
https://github.com/timoinutilis/lowres-nx
https://github.com/libretro/mame2000-libretro
https://github.com/libretro/nxengine-libretro
https://github.com/libretro/libretro-o2em
https://github.com/libretro/picodrive
https://github.com/libretro/libretro-pocketcdg
https://git.libretro.com/libretro/potator
https://github.com/libretro/libretro-prboom
https://github.com/libretro/prosystem-libretro
https://github.com/libretro/RACE
https://github.com/libretro/retro8
https://github.com/libretro/snes9x2002
https://github.com/libretro/snes9x2005
https://github.com/libretro/stella2014-libretro
https://github.com/Zlika/theodore
https://github.com/minkcv/vm
https://github.com/libretro/xmil-libretro

┳┓┏┓┓┏┏┓
┃┃┣ ┃┃┗┓
┻┛┗┛┗┛┗┛
        
@kobil (@kobily)
@osaka (@bnister)
@adcockm


This archive was compiled by @adcockm